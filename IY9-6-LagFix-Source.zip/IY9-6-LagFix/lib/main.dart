import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';

void main() => runApp(const LagFixApp());

class LagFixApp extends StatelessWidget {
  const LagFixApp({super.key});

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF9B5CFF);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'IY9-6 LagFix',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090912),
        colorScheme: ColorScheme.fromSeed(
          seedColor: purple,
          brightness: Brightness.dark,
          surface: const Color(0xFF171426),
        ),
        useMaterial3: true,
      ),
      home: const DashboardPage(),
    );
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  String game = 'Fortnite';
  String region = 'Middle East';
  bool testing = false;
  bool cancelRequested = false;
  double? ping;
  double? jitter;
  double? loss;
  String status = 'جاهز للفحص';
  String endpoint = '1.1.1.1:443';

  Future<double?> _probe() async {
    final watch = Stopwatch()..start();
    try {
      final socket = await Socket.connect(
        '1.1.1.1', 443,
        timeout: const Duration(seconds: 3),
      );
      watch.stop();
      socket.destroy();
      return watch.elapsedMicroseconds / 1000.0;
    } catch (_) {
      return null;
    }
  }

  Future<void> runTest() async {
    if (testing) {
      setState(() {
        cancelRequested = true;
        status = 'جارٍ إيقاف الفحص...';
      });
      return;
    }
    setState(() {
      testing = true;
      cancelRequested = false;
      status = 'جارٍ فحص الاتصال...';
      ping = null;
      jitter = null;
      loss = null;
    });

    final samples = <double>[];
    var failed = 0;
    const total = 8;
    for (var i = 0; i < total; i++) {
      if (cancelRequested) break;
      final value = await _probe();
      if (value == null) {
        failed++;
      } else {
        samples.add(value);
      }
      if (mounted) {
        setState(() {
          status = 'الفحص ${i + 1} من $total';
        });
      }
      await Future<void>.delayed(const Duration(milliseconds: 250));
    }

    if (!mounted) return;
    if (samples.isNotEmpty) {
      final avg = samples.reduce((a, b) => a + b) / samples.length;
      final deviations = <double>[];
      for (var i = 1; i < samples.length; i++) {
        deviations.add((samples[i] - samples[i - 1]).abs());
      }
      final avgJitter = deviations.isEmpty
          ? 0.0
          : deviations.reduce((a, b) => a + b) / deviations.length;
      setState(() {
        ping = avg;
        jitter = avgJitter;
        loss = failed / (samples.length + failed) * 100;
        testing = false;
        status = cancelRequested ? 'تم إيقاف الفحص' : 'اكتمل الفحص';
      });
    } else {
      setState(() {
        testing = false;
        status = 'تعذر الاتصال. تحقق من الإنترنت وحاول مجدداً.';
        loss = 100;
      });
    }
  }

  String fmt(double? value, {String suffix = ' ms'}) =>
      value == null ? '--' : '${value.toStringAsFixed(1)}$suffix';

  Widget panel({required Widget child}) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF171426),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFF302943)),
        ),
        child: child,
      );

  @override
  Widget build(BuildContext context) {
    const muted = Color(0xFFAAA5BA);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF090912),
        title: Row(children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFF722BCE),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.bolt, color: Colors.white, size: 28),
          ),
          const SizedBox(width: 11),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('IY9-6', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
              Text('LAGFIX • ANDROID + WINDOWS',
                  style: TextStyle(fontSize: 10, color: Color(0xFFB99AFF))),
            ],
          ),
        ]),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Center(child: Chip(label: Text('BETA'))),
          )
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Gaming Network', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            const Text('أدوات تشخيص اتصال الألعاب ومراقبة الشبكة', style: TextStyle(color: muted)),
            const SizedBox(height: 18),
            panel(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('حالة الاتصال', style: TextStyle(fontWeight: FontWeight.bold)),
                  Chip(
                    label: Text(testing ? 'يفحص الآن' : 'متوقف'),
                    backgroundColor: testing ? Colors.orange.withOpacity(.16) : Colors.green.withOpacity(.13),
                    labelStyle: TextStyle(color: testing ? Colors.orangeAccent : Colors.greenAccent),
                  ),
                ]),
                const SizedBox(height: 12),
                Center(child: Column(children: [
                  Text(fmt(ping), style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w800, color: Color(0xFFB99AFF))),
                  const Text('متوسط زمن الاتصال إلى 1.1.1.1:443',
                      style: TextStyle(color: muted, fontSize: 11)),
                ])),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: runTest,
                    icon: Icon(testing ? Icons.stop : Icons.bolt),
                    label: Text(testing ? 'إيقاف الفحص' : 'بدء فحص الاتصال'),
                    style: FilledButton.styleFrom(
                      backgroundColor: testing ? const Color(0xFF8B3434) : const Color(0xFF722BCE),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Text(status, style: const TextStyle(color: muted, fontSize: 12)),
              ],
            )),
            const SizedBox(height: 14),
            panel(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('إعدادات الاختبار', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                const Text('اللعبة', style: TextStyle(color: muted)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: game,
                  decoration: const InputDecoration(border: OutlineInputBorder(), isDense: true),
                  items: const [
                    DropdownMenuItem(value: 'Fortnite', child: Text('Fortnite')),
                    DropdownMenuItem(value: 'Roblox', child: Text('Roblox')),
                  ],
                  onChanged: testing ? null : (v) => setState(() => game = v ?? game),
                ),
                const SizedBox(height: 12),
                const Text('المنطقة المختارة (للتنظيم فقط)', style: TextStyle(color: muted)),
                const SizedBox(height: 6),
                DropdownButtonFormField<String>(
                  value: region,
                  decoration: const InputDecoration(border: OutlineInputBorder(), isDense: true),
                  items: const [
                    DropdownMenuItem(value: 'Middle East', child: Text('Middle East')),
                    DropdownMenuItem(value: 'Europe', child: Text('Europe')),
                    DropdownMenuItem(value: 'Asia', child: Text('Asia')),
                  ],
                  onChanged: (v) => setState(() => region = v ?? region),
                ),
              ],
            )),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: _metric('Jitter', fmt(jitter), Icons.show_chart)),
              const SizedBox(width: 10),
              Expanded(child: _metric('فشل الاتصال', fmt(loss, suffix: '%'), Icons.wifi_off)),
            ]),
            const SizedBox(height: 14),
            panel(child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('معلومات مهمة', style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Text(
                  'هذا التطبيق يقيس زمن إنشاء اتصال TCP بخادم عام، ولا يقيس بنق سيرفر اللعبة مباشرة. اختيار المنطقة لا يغيّر مسار الإنترنت. لا توجد ميزة VPN أو توجيه مرور مدمجة في هذا الإصدار.',
                  style: TextStyle(color: muted, height: 1.5, fontSize: 12),
                ),
              ],
            )),
            const SizedBox(height: 20),
            const Center(child: Text('IY9-6 LagFix • Built for gamers',
                style: TextStyle(color: Color(0xFF777386), fontSize: 11))),
          ],
        ),
      ),
    );
  }

  Widget _metric(String title, String value, IconData icon) => Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: const Color(0xFF171426),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFF302943)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: const Color(0xFFB99AFF)),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(color: Color(0xFFAAA5BA), fontSize: 12)),
          const SizedBox(height: 3),
          Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ]),
      );
}
