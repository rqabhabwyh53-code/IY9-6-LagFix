# IY9-6 LagFix

مشروع Flutter متعدد المنصات (Android + Windows) لتشخيص الاتصال.

## المتطلبات
- Flutter SDK حديث
- Android Studio و Android SDK لبناء APK
- Visual Studio مع workload: Desktop development with C++ لبناء Windows

## التشغيل
```bash
flutter pub get
flutter run
```

## بناء Android APK
```bash
flutter build apk --release
```
الناتج: `build/app/outputs/flutter-apk/app-release.apk`

## بناء Windows
```bash
flutter config --enable-windows-desktop
flutter create --platforms=windows .
flutter build windows --release
```
الناتج داخل `build/windows/x64/runner/Release/`.

## حدود النسخة
- فحص TCP إلى `1.1.1.1:443` كمؤشر تقريبي لاتصال الشبكة.
- لا يقيس ping الخاص بسيرفر Fortnite أو Roblox.
- اختيار المنطقة واجهة تنظيمية فقط ولا يغيّر مسارات الاتصال.
- لا يتضمن VPN أو خوادم وسيطة أو تجاوز اشتراكات.
